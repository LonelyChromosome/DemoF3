package com.bpa.findbike;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.Typeface;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.io.DataInputStream;
import java.util.Collections;
import android.graphics.RectF;
import android.graphics.DashPathEffect;
import java.util.Comparator;
import java.util.PriorityQueue;

/** Standalone Find My Bike navigation prototype. No GPS and no network access. */
public class MainActivity extends Activity implements SensorEventListener {
    private static final int BLUE = Color.rgb(82, 205, 255);
    private static final int GOLD = Color.rgb(255, 200, 87);
    private static final int SURFACE = Color.rgb(12, 20, 31);
    private FrameLayout root;
    private MapSurface map;
    private TextView title, hint, currentButton, bikeButton, navigationButton, stepButton, state, routeModeButton;
    private int selection = 0; // 0 = fake current location; 1 = fake parked bike
    private boolean navigating = false;
    private SensorManager sensors;
    private Sensor headingSensor;
    private boolean hasSensor = false;
    private int demoSteps = 0;
    private boolean shortestMode = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8, 15, 25));
        getWindow().setNavigationBarColor(Color.rgb(8, 15, 25));
        sensors = (SensorManager) getSystemService(SENSOR_SERVICE);
        headingSensor = sensors.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        hasSensor = headingSensor != null;

        root = new FrameLayout(this);
        root.setBackgroundColor(SURFACE);
        setContentView(root);
        map = new MapSurface(this);
        root.addView(map, new FrameLayout.LayoutParams(-1, -1));
        createHeader();
        createControls();
        refreshUi();
    }

    private int dp(float v) { return (int) (getResources().getDisplayMetrics().density * v + 0.5f); }
    private TextView text(String label, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private android.graphics.drawable.GradientDrawable panel(int color, float radius) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), Color.rgb(41, 65, 81));
        return d;
    }
    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private void createHeader() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(15), dp(10), dp(15), dp(10));
        box.setBackground(panel(Color.rgb(15, 27, 42), 20));
        LinearLayout first = row();
        TextView brand = text("FIND MY BIKE  /  MAP TEST", 13, BLUE, true);
        first.addView(brand, new LinearLayout.LayoutParams(0, dp(26), 1));
        TextView demo = text("●  DEMO", 11, GOLD, true);
        first.addView(demo);
        box.addView(first);
        title = text("Chọn vị trí giả lập trên bản đồ", 17, Color.WHITE, true);
        title.setPadding(0, dp(2), 0, 0);
        box.addView(title);
        hint = text("Không sử dụng GPS thật", 12, Color.rgb(166, 182, 202), false);
        hint.setPadding(0, dp(5), 0, 0);
        box.addView(hint);
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        p.setMargins(dp(12), dp(14), dp(12), 0);
        root.addView(box, p);
    }

    private void createControls() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(16), dp(16), dp(16));
        panel.setBackground(panel(Color.rgb(12, 22, 35), 22));
        LinearLayout buttons = row();
        currentButton = text("◎  VỊ TRÍ", 13, Color.WHITE, true);
        bikeButton = text("◆  XE ĐỖ", 13, Color.WHITE, true);
        currentButton.setGravity(Gravity.CENTER);
        bikeButton.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams b = new LinearLayout.LayoutParams(0, dp(47), 1);
        b.setMargins(0, 0, dp(6), 0);
        buttons.addView(currentButton, b);
        LinearLayout.LayoutParams b2 = new LinearLayout.LayoutParams(0, dp(47), 1);
        b2.setMargins(dp(6), 0, 0, 0);
        buttons.addView(bikeButton, b2);
        panel.addView(buttons);
        routeModeButton = text("ƯU TIÊN LANE   ↔", 12, BLUE, true);
        routeModeButton.setGravity(Gravity.CENTER);
        routeModeButton.setPadding(0, dp(9), 0, dp(2));
        panel.addView(routeModeButton);
        routeModeButton.setOnClickListener(v -> { shortestMode = !shortestMode; map.rebuildRoute(); map.invalidate(); refreshUi(); });
        currentButton.setOnClickListener(v -> { if (navigating) exitNavigation(); selection = 0; refreshUi(); });
        bikeButton.setOnClickListener(v -> { if (navigating) exitNavigation(); selection = 1; refreshUi(); });
        state = text("", 12, Color.rgb(167, 184, 200), false);
        state.setPadding(dp(2), dp(9), 0, dp(9));
        panel.addView(state);
        LinearLayout action = row();
        navigationButton = text("DẪN ĐƯỜNG   →", 15, Color.rgb(5, 21, 33), true);
        navigationButton.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams navParams = new LinearLayout.LayoutParams(0, dp(51), 1);
        navParams.setMargins(0, 0, dp(5), 0);
        action.addView(navigationButton, navParams);
        stepButton = text("BƯỚC THỬ", 12, Color.WHITE, true);
        stepButton.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams stepParams = new LinearLayout.LayoutParams(dp(98), dp(51));
        stepParams.setMargins(dp(5), 0, 0, 0);
        action.addView(stepButton, stepParams);
        panel.addView(action);
        navigationButton.setOnClickListener(v -> {
            if (navigating) exitNavigation(); else startNavigation();
        });
        stepButton.setOnClickListener(v -> { if (navigating) { map.advanceDemoStep(); demoSteps++; refreshUi(); } else map.resetCamera(); });
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        p.setMargins(dp(12), 0, dp(12), dp(14));
        root.addView(panel, p);
    }

    private void startNavigation() {
        navigating = true;
        demoSteps = 0;
        map.navigate(true);
        refreshUi();
    }
    private void exitNavigation() {
        navigating = false;
        demoSteps = 0;
        map.navigate(false);
        refreshUi();
    }
    private void refreshUi() {
        currentButton.setBackground(panel(!navigating && selection == 0 ? Color.rgb(23, 85, 119) : Color.rgb(26, 40, 58), 13));
        bikeButton.setBackground(panel(!navigating && selection == 1 ? Color.rgb(119, 75, 24) : Color.rgb(26, 40, 58), 13));
        navigationButton.setBackground(panel(navigating ? Color.rgb(249, 203, 112) : BLUE, 13));
        stepButton.setBackground(panel(Color.rgb(31, 52, 73), 13));
        navigationButton.setText(navigating ? "THOÁT DẪN ĐƯỜNG" : "DẪN ĐƯỜNG   →");
        stepButton.setText(navigating ? "BƯỚC THỬ" : "TOÀN MAP");
        title.setText(navigating ? "Đang dẫn tới vị trí để xe" : selection == 0 ? "Chọn vị trí hiện tại (giả lập)" : "Chọn vị trí xe đã đỗ (giả lập)");
        hint.setText(navigating ? "Chạm điểm khác để giả lập đi lệch: tự tính lại tuyến" : "Chạm để đặt điểm • kéo / chụm để zoom");
        routeModeButton.setText(shortestMode ? "NGẮN NHẤT · ĐƯỢC ĐI XUYÊN TÒA NHÀ   ↔" : "ƯU TIÊN LANE · RẼ KHI LỆCH TUYẾN   ↔");
        state.setText(navigating ? "• Track + chấm bước chân  ·  Đã đi " + demoSteps + " bước thử" : "◎ Xanh: vị trí hiện tại     ◆ Vàng: xe đỗ");
        map.invalidate();
    }

    @Override protected void onResume() { super.onResume(); if (headingSensor != null) sensors.registerListener(this, headingSensor, SensorManager.SENSOR_DELAY_GAME); }
    @Override protected void onPause() { if (sensors != null) sensors.unregisterListener(this); super.onPause(); }
    @Override public void onAccuracyChanged(Sensor s, int accuracy) {}
    @Override public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() != Sensor.TYPE_ROTATION_VECTOR) return;
        float[] rotation = new float[9];
        SensorManager.getRotationMatrixFromVector(rotation, event.values);
        float[] orientation = new float[3];
        SensorManager.getOrientation(rotation, orientation);
        float angle = (float) Math.toDegrees(orientation[0]);
        map.setHeading(angle);
    }

    private final class MapSurface extends View {
        private final Bitmap bitmap;
        private final LaneGraph lanes;
        private static final float MAP_W = 1448f, MAP_H = 1086f;
        private final Paint paint = new Paint(3);
        private final Matrix transform = new Matrix();
        private final Matrix invert = new Matrix();
        private final ScaleGestureDetector scaleDetector;
        private PointF user = new PointF(550, 760);
        private final PointF bike = new PointF(1000, 720);
        private ArrayList<PointF> route = new ArrayList<>();
        private boolean ready = false;
        private float baseZoom = 1f, zoom = 1f, centerX, centerY, heading = 0f, displayedHeading = 0f;
        private float desiredZoom = 1f, desiredX, desiredY;
        private float downX, downY, lastX, lastY;
        private boolean moved = false;
        private boolean pinching = false;
        private long lastFrame = 0;
        private float pathTotal = 0f;
        private boolean routeOnLane = true;
        private int firstRoadSegment = -1, lastRoadSegment = -1;

        MapSurface(Context ctx) {
            super(ctx);
            setLayerType(View.LAYER_TYPE_HARDWARE, null); // GPU accelerates rotation and high resolution map zoom
            Bitmap image;
            try {
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inPreferredConfig = Bitmap.Config.RGB_565; // ~27 MB for 3x source
                image = BitmapFactory.decodeStream(getAssets().open("map_hires.webp"), null, opts);
            } catch (Exception e) { image = null; }
            bitmap = image;
            lanes = new LaneGraph(getAssets());
            scaleDetector = new ScaleGestureDetector(ctx, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScale(ScaleGestureDetector detector) {
                    // Pinch zoom works even while navigating.
                    float next = clamp(zoom * detector.getScaleFactor(), baseZoom * .9f, baseZoom * 12f);
                    zoom = desiredZoom = next;
                    invalidate();
                    return true;
                }
            });
            rebuildRoute();
        }
        float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
        void setHeading(float value) { heading = value; if (navigating) postInvalidateOnAnimation(); }

        @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            if (bitmap == null) return;
            baseZoom = Math.max(w / MAP_W * 1.08f, h / MAP_H * .57f);
            if (!ready) { zoom = desiredZoom = baseZoom; centerX = desiredX = MAP_W / 2f; centerY = desiredY = MAP_H / 2f; ready = true; }
        }
        void resetCamera() {
            if (bitmap == null) return;
            desiredZoom = baseZoom;
            desiredX = MAP_W * .5f;
            desiredY = MAP_H * .5f;
            postInvalidateOnAnimation();
        }
        void navigate(boolean enabled) {
            if (bitmap == null) return;
            if (enabled) {
                rebuildRoute();
                focusOnUser();
            } else {
                displayedHeading = 0;
                resetCamera();
            }
            postInvalidateOnAnimation();
        }
        private void focusOnUser() {
            desiredX = user.x;
            desiredY = user.y;
            desiredZoom = Math.max(baseZoom * 2.25f, getWidth() / MAP_W * 3.0f);
        }
        void advanceDemoStep() {
            if (route.size() < 2 || pathTotal <= 0f) return;
            PointF p = locationAlong(Math.min(pathTotal, Math.max(8f, pathTotal / 48f)));
            user.set(p.x, p.y);
            rebuildRoute(); // recalculate as soon as the user changes position
            focusOnUser();
            if (dist(user, bike) < 10f) { navigating = false; refreshUi(); }
            postInvalidateOnAnimation();
        }
        private PointF locationAlong(float d) {
            if (route.isEmpty()) return new PointF(user.x, user.y);
            for (int i = 1; i < route.size(); i++) {
                PointF a = route.get(i - 1), b = route.get(i);
                float len = (float) Math.hypot(b.x - a.x, b.y - a.y);
                if (d <= len) {
                    float t = len == 0 ? 0 : d / len;
                    return new PointF(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t);
                }
                d -= len;
            }
            PointF p = route.get(route.size() - 1);
            return new PointF(p.x, p.y);
        }
        void rebuildRoute() {
            Route result = lanes.route(user, bike, shortestMode);
            route = result.points;
            firstRoadSegment = result.firstRoadSegment;
            lastRoadSegment = result.lastRoadSegment;
            routeOnLane = result.onLane;
            pathTotal = 0f;
            for (int i = 1; i < route.size(); i++) pathTotal += dist(route.get(i - 1), route.get(i));
        }
        private float dist(PointF a, PointF b) { return (float) Math.hypot(a.x - b.x, a.y - b.y); }

        private void matrix() {
            transform.reset();
            // Camera anchored above the bottom controls so the navigation arrow stays visible.
            transform.postTranslate(-centerX, -centerY);
            transform.postScale(zoom, zoom);
            transform.postRotate(-displayedHeading);
            transform.postTranslate(getWidth() * .5f, getHeight() * .45f);
            transform.invert(invert);
        }
        private PointF screen(PointF source) {
            float[] p = {source.x, source.y}; transform.mapPoints(p); return new PointF(p[0], p[1]);
        }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            canvas.drawColor(Color.rgb(241, 242, 243));
            if (bitmap == null) { paint.setColor(Color.WHITE); paint.setTextSize(dp(16)); canvas.drawText("Không thể mở ảnh map", dp(30), dp(220), paint); return; }
            if (lastFrame == 0) lastFrame = SystemClock.uptimeMillis();
            long now = SystemClock.uptimeMillis();
            float strength = Math.min(.28f, .08f + (now - lastFrame) / 190f);
            lastFrame = now;
            centerX += (desiredX - centerX) * strength;
            centerY += (desiredY - centerY) * strength;
            zoom += (desiredZoom - zoom) * strength;
            float goal = navigating && hasSensor ? heading : 0;
            float shortest = ((goal - displayedHeading + 540f) % 360f) - 180f;
            displayedHeading += shortest * strength;
            matrix();
            canvas.save();
            canvas.concat(transform);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.WHITE);
            paint.setAlpha(255);
            paint.setFilterBitmap(true);
            canvas.drawBitmap(bitmap, null, new RectF(0, 0, MAP_W, MAP_H), paint);
            if (navigating) drawRoute(canvas);
            canvas.restore();
            drawMarker(canvas, screen(bike), GOLD, true, 0);
            drawMarker(canvas, screen(user), BLUE, false, navigating ? 0 : heading);
            if (navigating) {
                paint.setColor(Color.argb(200, 100, 218, 255));
                paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(2));
                PointF loc = screen(user);
                canvas.drawCircle(loc.x, loc.y, dp(29), paint);
                paint.setStyle(Paint.Style.FILL);
            }
            if (Math.abs(desiredZoom - zoom) > .001f || Math.abs(desiredX - centerX) > .05f || Math.abs(desiredY - centerY) > .05f || Math.abs(shortest) > .1f) postInvalidateOnAnimation();
        }
        private void drawRoute(Canvas canvas) {
            if (route.size() < 2) return;
            float stroke = dp(1.7f) / zoom;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            for (int i = 1; i < route.size(); i++) {
                PointF a = route.get(i - 1), b = route.get(i);
                boolean offLane = !routeOnLane || i <= firstRoadSegment || i > lastRoadSegment;
                paint.setColor(offLane ? Color.rgb(250, 178, 75) : Color.rgb(24, 177, 219));
                paint.setStrokeWidth(stroke);
                if (offLane) paint.setPathEffect(new DashPathEffect(new float[]{dp(5) / zoom, dp(5) / zoom}, 0));
                else paint.setPathEffect(null);
                canvas.drawLine(a.x, a.y, b.x, b.y, paint);
            }
            paint.setPathEffect(null);
            paint.setStyle(Paint.Style.FILL);
            float spacing = dp(20) / zoom;
            for (float d = spacing; d < pathTotal; d += spacing) {
                PointF p = locationAlong(d);
                PointF p0 = locationAlong(Math.max(0, d - 3 / zoom));
                PointF p1 = locationAlong(Math.min(pathTotal, d + 3 / zoom));
                float theta = (float) Math.atan2(p1.y - p0.y, p1.x - p0.x);
                float sideways = ((int)(d / spacing) % 2 == 0 ? -1f : 1f) * dp(3.3f) / zoom;
                paint.setColor(Color.rgb(20, 175, 221));
                canvas.drawCircle(p.x - (float)Math.sin(theta) * sideways,
                    p.y + (float)Math.cos(theta) * sideways, dp(2.65f)/zoom, paint);
                paint.setColor(Color.WHITE);
                canvas.drawCircle(p.x - (float)Math.sin(theta) * sideways,
                    p.y + (float)Math.cos(theta) * sideways, dp(.82f)/zoom, paint);
            }
        }
        private void drawMarker(Canvas c, PointF p, int color, boolean parking, float headingValue) {
            float r = dp(parking ? 12 : 13);
            paint.setStyle(Paint.Style.FILL); paint.setColor(Color.argb(130, 4, 21, 34));
            c.drawCircle(p.x, p.y + dp(3), r + dp(7), paint);
            paint.setColor(Color.WHITE); c.drawCircle(p.x, p.y, r + dp(4), paint);
            paint.setColor(color); c.drawCircle(p.x, p.y, r, paint);
            if (parking) {
                paint.setColor(Color.rgb(29, 32, 43));
                paint.setTextSize(dp(16)); paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setTextAlign(Paint.Align.CENTER);
                c.drawText("P", p.x, p.y + dp(5.5f), paint);
            } else {
                c.save(); c.rotate(headingValue, p.x, p.y);
                Path triangle = new Path();
                triangle.moveTo(p.x, p.y - dp(9)); triangle.lineTo(p.x - dp(5.5f), p.y + dp(6)); triangle.lineTo(p.x, p.y + dp(3)); triangle.lineTo(p.x + dp(5.5f), p.y + dp(6)); triangle.close();
                paint.setColor(Color.rgb(5, 27, 46)); c.drawPath(triangle, paint);
                c.restore();
            }
            paint.setTypeface(Typeface.DEFAULT); paint.setTextAlign(Paint.Align.LEFT);
            paint.setColor(Color.WHITE); paint.setTextSize(dp(11));
            String label = parking ? "XE ĐỖ" : "BẠN";
            float w = paint.measureText(label);
            float tx = clamp(p.x - w / 2, dp(10), getWidth() - w - dp(10));
            paint.setColor(Color.argb(205, 8, 20, 32));
            c.drawRoundRect(tx - dp(6), p.y - dp(39), tx + w + dp(6), p.y - dp(21), dp(5), dp(5), paint);
            paint.setColor(Color.WHITE); c.drawText(label, tx, p.y - dp(26), paint);
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            scaleDetector.onTouchEvent(event);
            int action = event.getActionMasked();
            if (action == MotionEvent.ACTION_POINTER_DOWN) pinching = true;
            if (action == MotionEvent.ACTION_DOWN) {
                downX = lastX = event.getX(); downY = lastY = event.getY(); moved = false;
                return true;
            }
            if (action == MotionEvent.ACTION_MOVE) {
                if (event.getPointerCount() == 1 && !scaleDetector.isInProgress()) {
                    float dx = event.getX() - lastX, dy = event.getY() - lastY;
                    if (Math.abs(event.getX() - downX) > dp(9) || Math.abs(event.getY() - downY) > dp(9)) moved = true;
                    float[] delta = {dx,dy};
                    invert.mapVectors(delta);
                    centerX = desiredX = clamp(centerX - delta[0], -MAP_W*.18f, MAP_W*1.18f);
                    centerY = desiredY = clamp(centerY - delta[1], -MAP_H*.18f, MAP_H*1.18f);
                    invalidate();
                }
                lastX = event.getX(); lastY = event.getY(); return true;
            }
            if (action == MotionEvent.ACTION_UP) {
                if (!moved && !pinching && !scaleDetector.isInProgress()) {
                    float[] point = {event.getX(), event.getY()};
                    invert.mapPoints(point);
                    if (point[0] >= 0 && point[1] >= 0 && point[0] <= MAP_W && point[1] <= MAP_H) {
                        if (navigating || selection == 0) {
                            user.set(point[0], point[1]);
                            if (navigating) focusOnUser();
                        } else bike.set(point[0], point[1]);
                        rebuildRoute(); invalidate();
                    }
                }
                pinching = false; return true;
            }
            if (action == MotionEvent.ACTION_CANCEL) { pinching = false; return true; }
            return true;
        }
    }

    /** A true graph of road centerlines extracted once from the full-resolution source image.
     *  No buildings are marked as obstacles: users can deliberately leave the suggested lane.
     *  Snap to nearest road, A* along road, connect to destination offroad; fallback when no road.
     */
    private static final class Route {
        ArrayList<PointF> points = new ArrayList<>();
        int firstRoadSegment = -1, lastRoadSegment = -1;
        boolean onLane = false;
    }
    private static final class LaneGraph {
        private int width = 0, height = 0;
        private int[] grid, xs, ys;
        private static final int[] DX = {-1, 0, 1, 1, 1, 0, -1, -1};
        private static final int[] DY = {-1, -1, -1, 0, 1, 1, 1, 0};
        LaneGraph(android.content.res.AssetManager assets) {
            try (DataInputStream in = new DataInputStream(assets.open("lanes.bin"))) {
                width = in.readUnsignedShort(); height = in.readUnsignedShort();
                int n = in.readUnsignedShort();
                xs = new int[n]; ys = new int[n];
                grid = new int[width * height]; Arrays.fill(grid,-1);
                for (int i=0;i<n;i++) {
                    xs[i] = in.readUnsignedShort(); ys[i] = in.readUnsignedShort();
                    grid[ys[i] * width + xs[i]] = i;
                }
            } catch(Exception e) { width = 0; xs = new int[0]; ys = new int[0]; }
        }
        private float distance(PointF a, PointF b) {
            return (float)Math.hypot(a.x-b.x,a.y-b.y);
        }
        private PointF pixel(int i) { return new PointF(xs[i]*2f,ys[i]*2f); }
        private int closest(PointF p) {
            float best = Float.MAX_VALUE; int at = -1;
            for (int i=0;i<xs.length;i++) {
                float dx=2*xs[i]-p.x, dy=2*ys[i]-p.y;
                float d=dx*dx+dy*dy;
                if (d<best) {best=d;at=i;}
            }
            return at;
        }
        Route route(PointF from, PointF to, boolean freeWalk) {
            Route out = new Route();
            out.points.add(new PointF(from.x,from.y));
            float direct = distance(from,to);
            if (direct < 7) {out.points.add(new PointF(to.x,to.y));return out;}
            if (xs.length < 2 || freeWalk) {out.points.add(new PointF(to.x,to.y));return out;}
            int start = closest(from), goal = closest(to);
            PointF a=pixel(start),b=pixel(goal);
            float connectStart = distance(from,a), connectEnd = distance(to,b);
            // When the lane network is too far away, use a dotted walkable connector.
            if (connectStart > 320 || connectEnd > 320) {out.points.add(new PointF(to.x,to.y));return out;}
            float[] score = new float[xs.length];Arrays.fill(score,Float.POSITIVE_INFINITY);
            int[] parent = new int[xs.length];Arrays.fill(parent,-1);
            boolean[] closed = new boolean[xs.length];
            PriorityQueue<Edge> open = new PriorityQueue<>(Comparator.comparingDouble(n->n.f));
            score[start]=0;open.add(new Edge(start,distance(a,b)));
            while (!open.isEmpty()) {
                Edge edge=open.poll();int node=edge.id;
                if(closed[node])continue;
                closed[node]=true;
                if(node==goal)break;
                int x=xs[node], y=ys[node];
                for(int k=0;k<8;k++) {
                    int nx=x+DX[k],ny=y+DY[k];
                    if(nx<0||ny<0||nx>=width||ny>=height)continue;
                    int j=grid[ny*width+nx];
                    if(j<0||closed[j])continue;
                    float cost = (DX[k]==0||DY[k]==0)?2f:2.828427f;
                    float next=score[node]+cost;
                    if(next<score[j]) {
                        score[j]=next;parent[j]=node;
                        open.add(new Edge(j,next+distance(pixel(j),b)));
                    }
                }
            }
            if(start != goal && parent[goal]<0) {out.points.add(new PointF(to.x,to.y));return out;}
            ArrayList<PointF> road=new ArrayList<>();
            for(int at=goal;at!=-1;at=parent[at]) {
                road.add(pixel(at));
                if(at==start)break;
            }
            Collections.reverse(road);
            // Simplify the centerline without moving it off the roads by more than ~3px.
            ArrayList<PointF> smooth = new ArrayList<>();
            if (!road.isEmpty()) {
                simplify(road, 0, road.size()-1, 2.8f, smooth);
                smooth.add(road.get(road.size()-1));
            }
            out.firstRoadSegment = 1;
            out.points.addAll(smooth);
            out.lastRoadSegment = Math.max(1,out.points.size()-1);
            out.points.add(new PointF(to.x,to.y));
            out.onLane = true;
            return out;
        }
        private static final class Edge {
            final int id;final float f;
            Edge(int i,float p) {id=i;f=p;}
        }
        private static void simplify(ArrayList<PointF> list,int first,int last,float tol,ArrayList<PointF> out) {
            PointF a=list.get(first),b=list.get(last);
            int where=-1;float max=tol;
            float dx=b.x-a.x,dy=b.y-a.y,den=dx*dx+dy*dy;
            for(int i=first+1;i<last;i++) {
                PointF p=list.get(i);
                float t=den==0 ? 0:Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy)/den));
                float d=(float)Math.hypot(p.x-(a.x+t*dx),p.y-(a.y+t*dy));
                if(d>max){max=d;where=i;}
            }
            if(where<0) out.add(a);
            else {simplify(list,first,where,tol,out);simplify(list,where,last,tol,out);}
        }
    }
}
